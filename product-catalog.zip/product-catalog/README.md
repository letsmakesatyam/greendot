# 🗂 ProductCatalog — Enterprise Product Management

A full-stack product catalog application built with **Next.js 14** (frontend) and **Django 4.2** (backend).

---

## 🗂 Project Structure

```
product-catalog/
├── backend/          # Django REST API
│   ├── backend/      # Django project settings
│   ├── products/     # Products app (models, views, serializers)
│   ├── manage.py
│   └── requirements.txt
└── frontend/         # Next.js 14 app
    ├── src/
    │   ├── app/      # Next.js App Router pages
    │   ├── components/
    │   └── lib/
    └── package.json
```

---

## 🚀 Local Setup (Step by Step)

### Prerequisites
- Python 3.10+
- Node.js 18+
- npm or yarn

---

### 1. Backend Setup (Django)

```bash
cd product-catalog/backend

# Create virtual environment
python -m venv venv

# Activate (Mac/Linux)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy env file
cp .env.example .env

# Run migrations
python manage.py migrate

# Create superuser (for /admin panel)
python manage.py createsuperuser

# Seed with dummy data
python manage.py seed_data

# Start backend server
python manage.py runserver
```

Backend runs at: **http://localhost:8000**
Django Admin: **http://localhost:8000/admin**
API Docs base: **http://localhost:8000/api/products/**

---

### 2. Frontend Setup (Next.js)

In a new terminal:

```bash
cd product-catalog/frontend

# Install dependencies
npm install

# Copy env file
cp .env.example .env.local

# Edit .env.local - make sure API URL is correct:
# NEXT_PUBLIC_API_URL=http://localhost:8000

# Start frontend
npm run dev
```

Frontend runs at: **http://localhost:3000**

---

## 🌐 Deploy on Render

### Backend (Django on Render Web Service)

1. Go to [render.com](https://render.com) → New → **Web Service**
2. Connect your GitHub repo
3. Set **Root Directory**: `backend`
4. **Build Command**:
   ```
   pip install -r requirements.txt && python manage.py migrate && python manage.py seed_data && python manage.py collectstatic --noinput
   ```
5. **Start Command**:
   ```
   gunicorn backend.wsgi:application
   ```
6. **Environment Variables** (in Render dashboard):
   ```
   SECRET_KEY=your-very-long-secret-key-here
   DEBUG=False
   ALLOWED_HOSTS=your-backend.onrender.com,localhost
   CORS_ALLOWED_ORIGINS=https://your-frontend.vercel.app
   CORS_ALLOW_ALL_ORIGINS=True
   DATABASE_URL=  (Render auto-fills if you add a PostgreSQL DB)
   ```
7. Optional: Add a **PostgreSQL** database from Render → it will auto-set DATABASE_URL

### Frontend (Next.js on Render or Vercel)

**Option A — Vercel (Recommended for Next.js)**:
1. Go to [vercel.com](https://vercel.com) → Import Project
2. Set **Root Directory**: `frontend`
3. Add env variable:
   ```
   NEXT_PUBLIC_API_URL=https://your-backend.onrender.com
   ```
4. Deploy!

**Option B — Render Static Site**:
1. New → Static Site
2. Root Directory: `frontend`
3. Build Command: `npm install && npm run build`
4. Publish Directory: `.next`
5. Add same env variable

---

## 📖 API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products/` | List all products (filterable) |
| POST | `/api/products/` | Create product (multipart for image) |
| GET | `/api/products/{id}/` | Get single product |
| PATCH | `/api/products/{id}/` | Update product |
| DELETE | `/api/products/{id}/` | Delete product |
| GET | `/api/products/stats/` | Dashboard statistics |
| GET | `/api/products/choices/` | Dropdown options |
| POST | `/api/products/bulk_import/` | Import CSV file |
| GET | `/api/products/export_csv/` | Export all as CSV |

### Filters (query params)
```
?search=carpet
?category=Building Care
?geo_bucket=MEA Core
?source=EU
?is_green=true
?needs_evaluation=true
?product_hierarchy=Core
?page=2
```

---

## ✨ Features

- **Dashboard** with live stats and charts
- **Product table** with search, multi-filter, pagination
- **Add/Edit/View** products via modal forms
- **Image upload** with drag & drop
- **CSV bulk import** with error reporting
- **CSV export** for all products
- **Analytics page** with category, geo, source charts
- **Admin panel** for data operations
- Dark, professional UI with Syne + DM Sans typography
- Responsive layout

---

## 🛠 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | Next.js 14, TypeScript, Tailwind CSS |
| State/Data | TanStack Query v5 |
| Forms | React Hook Form + Zod |
| Charts | Recharts |
| File Upload | React Dropzone |
| Backend | Django 4.2, Django REST Framework |
| DB | SQLite (dev) / PostgreSQL (prod) |
| Auth | Django Admin |
| Deploy | Render (backend), Vercel (frontend) |
