'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Package, ShieldCheck, Upload, Download,
  BarChart3, Settings, ChevronRight, Boxes, Leaf
} from 'lucide-react';

const navItems = [
  { label: 'Dashboard', href: '/', icon: LayoutDashboard },
  { label: 'Products', href: '/products', icon: Package },
  { label: 'Analytics', href: '/analytics', icon: BarChart3 },
  { label: 'Green Products', href: '/products?is_green=true', icon: Leaf },
  { label: 'Needs Eval', href: '/products?needs_evaluation=true', icon: ShieldCheck },
  { label: 'Admin Panel', href: '/admin', icon: Settings, divider: true },
  { label: 'Import CSV', href: '/admin/import', icon: Upload },
  { label: 'Export', href: '/admin/export', icon: Download },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 flex flex-col z-50"
      style={{ background: 'var(--bg-secondary)', borderRight: '1px solid var(--border)' }}>
      {/* Logo */}
      <div className="px-6 py-6 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #6271f3, #a78bfa)' }}>
            <Boxes size={16} className="text-white" />
          </div>
          <div>
            <div className="font-display font-700 text-sm" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
              ProductCatalog
            </div>
            <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Enterprise Edition</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href.split('?')[0]));

          return (
            <div key={item.href}>
              {item.divider && (
                <div className="my-3 mx-3 border-t" style={{ borderColor: 'var(--border)' }} />
              )}
              <Link href={item.href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all group',
                  isActive
                    ? 'text-white'
                    : 'hover:text-white'
                )}
                style={{
                  background: isActive ? 'rgba(98,113,243,0.15)' : undefined,
                  color: isActive ? 'white' : 'var(--text-muted)',
                  border: isActive ? '1px solid rgba(98,113,243,0.3)' : '1px solid transparent',
                }}>
                <Icon size={16} className={isActive ? 'text-brand-400' : ''} style={{ color: isActive ? '#818cf8' : undefined }} />
                <span className="flex-1 font-medium">{item.label}</span>
                {isActive && <ChevronRight size={14} style={{ color: '#818cf8' }} />}
              </Link>
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-6 py-4 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="text-xs" style={{ color: 'var(--text-muted)' }}>v1.0.0 · MEA Edition</div>
      </div>
    </aside>
  );
}
