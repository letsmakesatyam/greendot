'use client';
import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { productsApi, Product } from '@/lib/api';
import toast from 'react-hot-toast';
import { useDropzone } from 'react-dropzone';
import { Upload, X, ImageIcon, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const schema = z.object({
  category: z.string().min(1),
  application: z.string().min(1),
  positioning: z.string().min(1),
  fg_code: z.string().min(1),
  product_name: z.string().min(1),
  product_hierarchy: z.string().min(1),
  application_type: z.string().optional(),
  geo_bucket: z.string().min(1),
  pack_size: z.string().optional(),
  source: z.string().min(1),
  is_green: z.boolean().default(false),
  fc: z.string().optional(),
  flag_est: z.number().default(0),
  flag_ke: z.number().default(0),
  needs_evaluation: z.boolean().default(false),
  is_export: z.boolean().default(false),
  description: z.string().optional(),
  is_active: z.boolean().default(true),
});

type FormData = z.infer<typeof schema>;

interface ProductFormProps {
  product?: Product;
  onSuccess?: () => void;
  onCancel?: () => void;
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--text-secondary)', fontFamily: 'Syne, sans-serif', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
        {label}
      </label>
      {children}
      {error && <p className="text-xs mt-1" style={{ color: '#ef4444' }}>{error}</p>}
    </div>
  );
}

const inputClass = "w-full px-3 py-2.5 rounded-lg text-sm transition-all";
const inputStyle = {
  background: 'rgba(255,255,255,0.04)',
  border: '1px solid rgba(255,255,255,0.1)',
  color: 'var(--text-primary)',
};

export function ProductForm({ product, onSuccess, onCancel }: ProductFormProps) {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(product?.product_image_url || null);
  const qc = useQueryClient();

  const { data: choices } = useQuery({
    queryKey: ['choices'],
    queryFn: () => productsApi.choices().then(r => r.data),
  });

  const { register, handleSubmit, formState: { errors }, watch, setValue } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: product ? {
      category: product.category,
      application: product.application,
      positioning: product.positioning,
      fg_code: product.fg_code,
      product_name: product.product_name,
      product_hierarchy: product.product_hierarchy,
      application_type: product.application_type,
      geo_bucket: product.geo_bucket,
      pack_size: product.pack_size,
      source: product.source,
      is_green: product.is_green,
      fc: product.fc,
      flag_est: product.flag_est,
      flag_ke: product.flag_ke,
      needs_evaluation: product.needs_evaluation,
      is_export: product.is_export,
      description: product.description,
      is_active: product.is_active,
    } : {
      category: 'Building Care',
      geo_bucket: 'MEA Core',
      source: 'EU',
      product_hierarchy: 'Core',
      is_green: false,
      needs_evaluation: false,
      is_export: false,
      is_active: true,
      flag_est: 0,
      flag_ke: 0,
    },
  });

  const mutation = useMutation({
    mutationFn: (data: FormData) => {
      const form = new FormData();
      Object.entries(data).forEach(([k, v]) => {
        if (v !== undefined && v !== null) form.append(k, String(v));
      });
      if (imageFile) form.append('product_image', imageFile);
      return product ? productsApi.update(product.id, form) : productsApi.create(form);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['products'] });
      qc.invalidateQueries({ queryKey: ['stats'] });
      toast.success(product ? 'Product updated!' : 'Product created!');
      onSuccess?.();
    },
    onError: (err: any) => {
      const msg = err.response?.data ? JSON.stringify(err.response.data) : 'Something went wrong';
      toast.error(msg.substring(0, 100));
    },
  });

  const onDrop = useCallback((files: File[]) => {
    const file = files[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'image/*': [] }, maxFiles: 1,
  });

  const selectStyle = { ...inputStyle };

  return (
    <form onSubmit={handleSubmit(d => mutation.mutate(d))} className="space-y-6">
      {/* Image Upload */}
      <div>
        <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--text-secondary)', fontFamily: 'Syne, sans-serif', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
          Product Image
        </label>
        <div {...getRootProps()} className={cn(
          'relative rounded-xl border-2 border-dashed transition-all cursor-pointer',
          isDragActive ? 'border-brand-500 bg-brand-500/10' : 'border-white/10 hover:border-white/20'
        )}>
          <input {...getInputProps()} />
          {imagePreview ? (
            <div className="relative h-36 rounded-xl overflow-hidden">
              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
              <button type="button" onClick={(e) => { e.stopPropagation(); setImageFile(null); setImagePreview(null); }}
                className="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(0,0,0,0.6)' }}>
                <X size={14} className="text-white" />
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-28 gap-2">
              <ImageIcon size={24} style={{ color: 'var(--text-muted)' }} />
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {isDragActive ? 'Drop here' : 'Drag & drop or click to upload'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Core Fields */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="FG Code *" error={errors.fg_code?.message}>
          <input {...register('fg_code')} placeholder="e.g. 6101981" className={inputClass} style={inputStyle} />
        </Field>
        <Field label="Category *" error={errors.category?.message}>
          <select {...register('category')} className={inputClass} style={selectStyle}>
            {(choices?.categories ?? ['Building Care']).map(c => <option key={c} value={c} style={{ background: '#1c2539' }}>{c}</option>)}
          </select>
        </Field>
        <Field label="Product Name *" error={errors.product_name?.message}>
          <input {...register('product_name')} placeholder="Full product name" className={inputClass} style={inputStyle} />
        </Field>
        <Field label="Application *" error={errors.application?.message}>
          <input {...register('application')} placeholder="e.g. Air Freshener" className={inputClass} style={inputStyle} />
        </Field>
        <Field label="Positioning *" error={errors.positioning?.message}>
          <input {...register('positioning')} placeholder="e.g. Hard Package Air Freshener" className={inputClass} style={inputStyle} />
        </Field>
        <Field label="Product Hierarchy *" error={errors.product_hierarchy?.message}>
          <select {...register('product_hierarchy')} className={inputClass} style={selectStyle}>
            {(choices?.product_hierarchies ?? ['Core', 'Enhanced', 'Specialty', 'Country']).map(c => (
              <option key={c} value={c} style={{ background: '#1c2539' }}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Geo Bucket *" error={errors.geo_bucket?.message}>
          <select {...register('geo_bucket')} className={inputClass} style={selectStyle}>
            {(choices?.geo_buckets ?? ['MEA Core', 'MEP Only', 'T&I Only']).map(c => (
              <option key={c} value={c} style={{ background: '#1c2539' }}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Source *" error={errors.source?.message}>
          <select {...register('source')} className={inputClass} style={selectStyle}>
            {(choices?.sources ?? ['EU', 'US', 'TR', 'UAE', 'IN']).map(c => (
              <option key={c} value={c} style={{ background: '#1c2539' }}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Pack Size">
          <input {...register('pack_size')} placeholder="e.g. 2x5L, 12x1L" className={inputClass} style={inputStyle} />
        </Field>
        <Field label="Application Type">
          <input {...register('application_type')} placeholder="e.g. Core, Specialty" className={inputClass} style={inputStyle} />
        </Field>
        <Field label="FC">
          <input {...register('fc')} placeholder="e.g. Ex" className={inputClass} style={inputStyle} />
        </Field>
      </div>

      {/* Flags row */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Flag EST (0 or 1)">
          <input {...register('flag_est', { valueAsNumber: true })} type="number" min={0} max={1} className={inputClass} style={inputStyle} />
        </Field>
        <Field label="Flag KE (0 or 1)">
          <input {...register('flag_ke', { valueAsNumber: true })} type="number" min={0} max={1} className={inputClass} style={inputStyle} />
        </Field>
      </div>

      {/* Toggles */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { name: 'is_green', label: 'Green Product', color: '#10b981' },
          { name: 'needs_evaluation', label: 'Needs Evaluation', color: '#f59e0b' },
          { name: 'is_export', label: 'Export', color: '#6271f3' },
          { name: 'is_active', label: 'Active', color: '#10b981' },
        ].map(({ name, label, color }) => (
          <label key={name} className="flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer"
            style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <input type="checkbox" {...register(name as keyof FormData)} className="hidden" />
            <div className="w-9 h-5 rounded-full transition-all relative"
              style={{ background: watch(name as keyof FormData) ? color : 'rgba(255,255,255,0.1)' }}
              onClick={() => setValue(name as keyof FormData, !watch(name as keyof FormData) as any)}>
              <div className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all"
                style={{ left: watch(name as keyof FormData) ? '18px' : '2px' }} />
            </div>
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{label}</span>
          </label>
        ))}
      </div>

      {/* Description */}
      <Field label="Description">
        <textarea {...register('description')} rows={3} placeholder="Optional product description..."
          className={inputClass} style={{ ...inputStyle, resize: 'none' }} />
      </Field>

      {/* Actions */}
      <div className="flex gap-3 pt-2">
        <button type="submit" disabled={mutation.isPending}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm text-white transition-all"
          style={{ background: 'linear-gradient(135deg, #6271f3, #818cf8)', opacity: mutation.isPending ? 0.7 : 1 }}>
          {mutation.isPending ? <Loader2 size={16} className="animate-spin" /> : null}
          {product ? 'Update Product' : 'Create Product'}
        </button>
        {onCancel && (
          <button type="button" onClick={onCancel}
            className="px-6 py-3 rounded-xl text-sm font-semibold transition-all"
            style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-secondary)', border: '1px solid rgba(255,255,255,0.08)' }}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
