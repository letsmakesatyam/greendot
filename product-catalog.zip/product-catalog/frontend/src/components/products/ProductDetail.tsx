'use client';
import { Product } from '@/lib/api';
import { Leaf, AlertTriangle, Package, CheckCircle, XCircle } from 'lucide-react';

export function ProductDetail({ product }: { product: Product }) {
  const Row = ({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) => (
    <div className="flex justify-between py-2.5 border-b" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
      <span className="text-xs" style={{ color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontFamily: 'Syne, sans-serif' }}>{label}</span>
      <span className={mono ? 'font-mono text-xs' : 'text-sm'} style={{ color: 'var(--text-primary)', textAlign: 'right', maxWidth: '60%' }}>
        {value}
      </span>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Image */}
      {product.product_image_url ? (
        <div className="w-full h-48 rounded-xl overflow-hidden">
          <img src={product.product_image_url} alt={product.product_name} className="w-full h-full object-cover" />
        </div>
      ) : (
        <div className="w-full h-36 rounded-xl flex items-center justify-center"
          style={{ background: 'rgba(98,113,243,0.08)', border: '1px dashed rgba(98,113,243,0.3)' }}>
          <Package size={40} style={{ color: 'rgba(98,113,243,0.4)' }} />
        </div>
      )}

      {/* Badges */}
      <div className="flex flex-wrap gap-2">
        {product.is_green && (
          <span className="badge" style={{ background: 'rgba(16,185,129,0.15)', color: '#10b981' }}>
            <Leaf size={11} /> Green
          </span>
        )}
        {product.needs_evaluation && (
          <span className="badge" style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>
            <AlertTriangle size={11} /> Needs Evaluation
          </span>
        )}
        {product.is_export && (
          <span className="badge" style={{ background: 'rgba(98,113,243,0.15)', color: '#818cf8' }}>Export</span>
        )}
        <span className="badge" style={{ background: product.is_active ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.06)', color: product.is_active ? '#10b981' : '#64748b' }}>
          {product.is_active ? <CheckCircle size={11} /> : <XCircle size={11} />}
          {product.is_active ? 'Active' : 'Inactive'}
        </span>
      </div>

      {/* Details */}
      <div>
        <Row label="FG Code" value={<code className="px-2 py-0.5 rounded text-xs" style={{ background: 'rgba(98,113,243,0.15)', color: '#818cf8' }}>{product.fg_code}</code>} />
        <Row label="Product Name" value={product.product_name} />
        <Row label="Category" value={product.category} />
        <Row label="Application" value={product.application} />
        <Row label="Positioning" value={product.positioning} />
        <Row label="Product Hierarchy" value={product.product_hierarchy} />
        <Row label="Application Type" value={product.application_type || '—'} />
        <Row label="Geo Bucket" value={product.geo_bucket} />
        <Row label="Pack Size" value={product.pack_size || '—'} />
        <Row label="Source" value={product.source} />
        <Row label="FC" value={product.fc || '—'} />
        <Row label="Flag EST" value={product.flag_est} />
        <Row label="Flag KE" value={product.flag_ke} />
      </div>

      {product.description && (
        <div className="p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
          <p className="text-xs mb-1" style={{ color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Description</p>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{product.description}</p>
        </div>
      )}
    </div>
  );
}
