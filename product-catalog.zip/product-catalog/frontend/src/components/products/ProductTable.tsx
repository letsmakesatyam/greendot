'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { productsApi, Product } from '@/lib/api';
import { Edit2, Trash2, Eye, Leaf, AlertTriangle, Package, ChevronLeft, ChevronRight } from 'lucide-react';
import toast from 'react-hot-toast';
import Image from 'next/image';

interface ProductTableProps {
  filters: Record<string, string>;
  onEdit: (p: Product) => void;
  onView: (p: Product) => void;
  isAdmin?: boolean;
}

export function ProductTable({ filters, onEdit, onView, isAdmin }: ProductTableProps) {
  const [page, setPage] = useState(1);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['products', filters, page],
    queryFn: () => productsApi.list({ ...filters, page }).then(r => r.data),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => productsApi.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['products'] }); toast.success('Product deleted'); },
    onError: () => toast.error('Failed to delete'),
  });

  const totalPages = data ? Math.ceil(data.count / 50) : 1;

  return (
    <div>
      {/* Table */}
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 340px)', overflowY: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ width: 60 }}>Img</th>
                <th>FG Code</th>
                <th>Product Name</th>
                <th>Category</th>
                <th>Application</th>
                <th>Hierarchy</th>
                <th>Geo Bucket</th>
                <th>Pack Size</th>
                <th>Source</th>
                <th>Green</th>
                <th>FC</th>
                <th>EST</th>
                <th>KE</th>
                <th>Status</th>
                <th style={{ width: 100 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && [...Array(8)].map((_, i) => (
                <tr key={i}>
                  {[...Array(15)].map((_, j) => (
                    <td key={j}><div className="skeleton h-4 rounded" style={{ width: j === 2 ? 160 : 60 }} /></td>
                  ))}
                </tr>
              ))}
              {!isLoading && data?.results.length === 0 && (
                <tr>
                  <td colSpan={15} className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
                    <Package size={40} className="mx-auto mb-3 opacity-30" />
                    <p>No products found</p>
                  </td>
                </tr>
              )}
              {data?.results.map((p) => (
                <tr key={p.id} className="group">
                  <td>
                    {p.product_image_url ? (
                      <div className="w-9 h-9 rounded-lg overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
                        <img src={p.product_image_url} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: 'rgba(98,113,243,0.1)' }}>
                        <Package size={14} style={{ color: '#818cf8' }} />
                      </div>
                    )}
                  </td>
                  <td>
                    <code className="text-xs px-2 py-0.5 rounded" style={{ background: 'rgba(98,113,243,0.1)', color: '#818cf8' }}>
                      {p.fg_code}
                    </code>
                  </td>
                  <td style={{ maxWidth: 200 }}>
                    <span className="block truncate font-medium" style={{ color: 'var(--text-primary)' }} title={p.product_name}>
                      {p.product_name}
                    </span>
                  </td>
                  <td className="text-xs">{p.category}</td>
                  <td className="text-xs">{p.application}</td>
                  <td>
                    <span className="badge text-xs" style={{
                      background: p.product_hierarchy === 'Core' ? 'rgba(98,113,243,0.15)' :
                        p.product_hierarchy === 'Enhanced' ? 'rgba(16,185,129,0.15)' :
                        p.product_hierarchy === 'Specialty' ? 'rgba(245,158,11,0.15)' : 'rgba(255,255,255,0.08)',
                      color: p.product_hierarchy === 'Core' ? '#818cf8' :
                        p.product_hierarchy === 'Enhanced' ? '#10b981' :
                        p.product_hierarchy === 'Specialty' ? '#f59e0b' : '#94a3b8',
                    }}>
                      {p.product_hierarchy}
                    </span>
                  </td>
                  <td className="text-xs">{p.geo_bucket}</td>
                  <td className="text-xs">{p.pack_size}</td>
                  <td>
                    <span className="badge text-xs" style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-secondary)' }}>
                      {p.source}
                    </span>
                  </td>
                  <td>
                    {p.is_green && <Leaf size={14} style={{ color: '#10b981' }} />}
                  </td>
                  <td className="text-xs" style={{ color: 'var(--text-muted)' }}>{p.fc}</td>
                  <td className="text-xs text-center">{p.flag_est}</td>
                  <td className="text-xs text-center">{p.flag_ke}</td>
                  <td>
                    {p.needs_evaluation ? (
                      <span className="badge text-xs" style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>
                        <AlertTriangle size={10} /> Eval
                      </span>
                    ) : p.is_active ? (
                      <span className="badge text-xs" style={{ background: 'rgba(16,185,129,0.15)', color: '#10b981' }}>Active</span>
                    ) : (
                      <span className="badge text-xs" style={{ background: 'rgba(255,255,255,0.06)', color: '#64748b' }}>Inactive</span>
                    )}
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button onClick={() => onView(p)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:bg-white/10"
                        style={{ color: 'var(--text-muted)' }}>
                        <Eye size={13} />
                      </button>
                      {isAdmin && (
                        <>
                          <button onClick={() => onEdit(p)}
                            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:bg-white/10"
                            style={{ color: 'var(--text-muted)' }}>
                            <Edit2 size={13} />
                          </button>
                          <button onClick={() => { if (confirm('Delete this product?')) deleteMutation.mutate(p.id); }}
                            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:bg-red-500/20"
                            style={{ color: 'var(--text-muted)' }}>
                            <Trash2 size={13} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {data && data.count > 50 && (
          <div className="flex items-center justify-between px-6 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
              Showing {((page - 1) * 50) + 1}–{Math.min(page * 50, data.count)} of {data.count}
            </span>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-all disabled:opacity-30"
                style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-secondary)' }}>
                <ChevronLeft size={14} />
              </button>
              <span className="flex items-center px-3 text-xs" style={{ color: 'var(--text-secondary)' }}>
                {page} / {totalPages}
              </span>
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-all disabled:opacity-30"
                style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-secondary)' }}>
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
