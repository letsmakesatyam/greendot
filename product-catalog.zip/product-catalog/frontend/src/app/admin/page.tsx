'use client';
import { useState, useCallback } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { ProductForm } from '@/components/products/ProductForm';
import { Modal } from '@/components/ui/Modal';
import { productsApi } from '@/lib/api';
import { useDropzone } from 'react-dropzone';
import toast from 'react-hot-toast';
import { Settings, Plus, Upload, Download, FileText, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';

function AdminCard({ title, description, icon: Icon, color, children }: {
  title: string; description: string; icon: React.ElementType; color: string; children: React.ReactNode;
}) {
  return (
    <div className="glass-card p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}20`, border: `1px solid ${color}30` }}>
          <Icon size={18} style={{ color }} />
        </div>
        <div>
          <h3 className="font-semibold text-sm" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--text-primary)' }}>{title}</h3>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{description}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

export default function AdminPage() {
  const [createOpen, setCreateOpen] = useState(false);
  const [importResult, setImportResult] = useState<{ created: number; updated: number; errors: string[] } | null>(null);

  const importMutation = useMutation({
    mutationFn: (file: File) => productsApi.bulkImport(file).then(r => r.data),
    onSuccess: (data) => {
      setImportResult(data);
      toast.success(`Imported: ${data.created} created, ${data.updated} updated`);
    },
    onError: () => toast.error('Import failed'),
  });

  const onDrop = useCallback((files: File[]) => {
    if (files[0]) importMutation.mutate(files[0]);
  }, [importMutation]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'text/csv': ['.csv'] }, maxFiles: 1,
  });

  const handleExport = async () => {
    try {
      const res = await productsApi.exportCsv();
      const url = URL.createObjectURL(new Blob([res.data]));
      const a = document.createElement('a');
      a.href = url;
      a.download = 'products_export.csv';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Export downloaded!');
    } catch {
      toast.error('Export failed');
    }
  };

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <Settings size={14} style={{ color: '#6271f3' }} />
            <span className="text-xs font-medium" style={{ color: '#6271f3', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Admin</span>
          </div>
          <h1 className="text-2xl font-bold gradient-text" style={{ fontFamily: 'Syne, sans-serif' }}>Admin Panel</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>Manage products and data operations</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Add Product */}
          <AdminCard title="Add Product" description="Create a new product entry manually" icon={Plus} color="#6271f3">
            <button onClick={() => setCreateOpen(true)}
              className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, #6271f3, #818cf8)' }}>
              Open Product Form
            </button>
          </AdminCard>

          {/* CSV Import */}
          <AdminCard title="Bulk Import via CSV" description="Upload a CSV file to import multiple products" icon={Upload} color="#10b981">
            <div {...getRootProps()} className="rounded-xl border-2 border-dashed p-6 text-center cursor-pointer transition-all"
              style={{ borderColor: isDragActive ? '#10b981' : 'rgba(255,255,255,0.1)', background: isDragActive ? 'rgba(16,185,129,0.08)' : undefined }}>
              <input {...getInputProps()} />
              {importMutation.isPending ? (
                <div className="flex flex-col items-center gap-2">
                  <Loader2 size={24} className="animate-spin" style={{ color: '#10b981' }} />
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Importing...</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <FileText size={24} style={{ color: 'var(--text-muted)' }} />
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Drop CSV file here or click to browse</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Columns: fg_code, category, application, positioning, product_name, product_hierarchy, geo_bucket, pack_size, source, is_green, fc, flag_est, flag_ke, needs_evaluation</p>
                </div>
              )}
            </div>

            {importResult && (
              <div className="mt-4 p-4 rounded-xl space-y-2" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="flex gap-4">
                  <span className="flex items-center gap-1.5 text-sm" style={{ color: '#10b981' }}>
                    <CheckCircle size={14} /> {importResult.created} Created
                  </span>
                  <span className="flex items-center gap-1.5 text-sm" style={{ color: '#818cf8' }}>
                    <CheckCircle size={14} /> {importResult.updated} Updated
                  </span>
                </div>
                {importResult.errors.length > 0 && (
                  <div className="text-xs" style={{ color: '#ef4444' }}>
                    <p className="flex items-center gap-1 mb-1"><AlertCircle size={12} /> {importResult.errors.length} errors:</p>
                    {importResult.errors.slice(0, 5).map((e, i) => <p key={i} className="ml-4">{e}</p>)}
                  </div>
                )}
              </div>
            )}
          </AdminCard>

          {/* Export */}
          <AdminCard title="Export to CSV" description="Download all products as a CSV file" icon={Download} color="#f59e0b">
            <button onClick={handleExport}
              className="w-full py-3 rounded-xl text-sm font-semibold transition-all"
              style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b', border: '1px solid rgba(245,158,11,0.25)' }}>
              Download CSV Export
            </button>
          </AdminCard>

          {/* CSV Template */}
          <AdminCard title="Download CSV Template" description="Get the import template with correct column headers" icon={FileText} color="#a78bfa">
            <button onClick={() => {
              const headers = 'fg_code,category,application,positioning,product_name,product_hierarchy,application_type,geo_bucket,pack_size,source,is_green,fc,flag_est,flag_ke,needs_evaluation,description\n';
              const example = '9999999,Building Care,Air Freshener,Hard Package Air Freshener,EXAMPLE PRODUCT 1L,Core,Core,MEA Core,1L,EU,false,,1,1,false,Optional description\n';
              const blob = new Blob([headers + example], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url; a.download = 'product_import_template.csv'; a.click();
              URL.revokeObjectURL(url);
              toast.success('Template downloaded!');
            }}
              className="w-full py-3 rounded-xl text-sm font-semibold transition-all"
              style={{ background: 'rgba(167,139,250,0.15)', color: '#a78bfa', border: '1px solid rgba(167,139,250,0.25)' }}>
              Download Template
            </button>
          </AdminCard>
        </div>
      </div>

      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Add New Product" size="xl">
        <ProductForm onSuccess={() => setCreateOpen(false)} onCancel={() => setCreateOpen(false)} />
      </Modal>
    </AppLayout>
  );
}
