'use client';
import { useQuery } from '@tanstack/react-query';
import { productsApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { Package, Leaf, AlertTriangle, Activity, TrendingUp, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const COLORS = ['#6271f3', '#818cf8', '#a78bfa', '#c4b5fd', '#7dd3fc', '#67e8f9'];

function StatCard({ label, value, icon: Icon, color, href }: {
  label: string; value: number; icon: React.ElementType; color: string; href?: string;
}) {
  const content = (
    <div className="glass-card p-6 group cursor-pointer transition-all duration-300 hover:scale-[1.02]"
      style={{ background: 'var(--bg-card)' }}>
      <div className="flex items-start justify-between mb-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: `${color}20`, border: `1px solid ${color}30` }}>
          <Icon size={18} style={{ color }} />
        </div>
        {href && <ArrowRight size={14} style={{ color: 'var(--text-muted)' }} className="group-hover:text-white transition-colors" />}
      </div>
      <div className="text-3xl font-bold mb-1" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--text-primary)' }}>
        {value.toLocaleString()}
      </div>
      <div className="text-sm" style={{ color: 'var(--text-muted)' }}>{label}</div>
    </div>
  );
  return href ? <Link href={href}>{content}</Link> : content;
}

function ChartCard({ title, data, dataKey, labelKey }: {
  title: string; data: any[]; dataKey: string; labelKey: string;
}) {
  return (
    <div className="glass-card p-6">
      <h3 className="text-sm font-semibold mb-6" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', fontSize: '11px' }}>
        {title}
      </h3>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
          <XAxis dataKey={labelKey} tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{ background: '#1c2539', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12 }}
            labelStyle={{ color: '#f1f5f9' }}
            itemStyle={{ color: '#94a3b8' }}
          />
          <Bar dataKey={dataKey} radius={[4, 4, 0, 0]}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function DashboardPage() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => productsApi.stats().then(r => r.data),
  });

  const { data: recentProducts } = useQuery({
    queryKey: ['products', 'recent'],
    queryFn: () => productsApi.list({ ordering: '-created_at', page_size: 5 }).then(r => r.data),
  });

  return (
    <AppLayout>
      <div className="p-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-2 mb-2">
            <Activity size={14} style={{ color: '#6271f3' }} />
            <span className="text-xs font-medium" style={{ color: '#6271f3', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Overview
            </span>
          </div>
          <h1 className="text-3xl font-bold gradient-text" style={{ fontFamily: 'Syne, sans-serif' }}>
            Product Dashboard
          </h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
            Real-time overview of your product catalog
          </p>
        </div>

        {/* Stats */}
        {isLoading ? (
          <div className="grid grid-cols-4 gap-4 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="glass-card p-6 skeleton h-32" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8 animate-slide-up">
            <StatCard label="Total Products" value={stats?.total ?? 0} icon={Package} color="#6271f3" href="/products" />
            <StatCard label="Active Products" value={stats?.active ?? 0} icon={TrendingUp} color="#10b981" href="/products?is_active=true" />
            <StatCard label="Green Products" value={stats?.green_products ?? 0} icon={Leaf} color="#10b981" href="/products?is_green=true" />
            <StatCard label="Needs Evaluation" value={stats?.needs_evaluation ?? 0} icon={AlertTriangle} color="#f59e0b" href="/products?needs_evaluation=true" />
          </div>
        )}

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {stats && (
            <>
              <ChartCard title="By Category" data={stats.by_category} dataKey="count" labelKey="category" />
              <ChartCard title="By Geo Bucket" data={stats.by_geo_bucket} dataKey="count" labelKey="geo_bucket" />
              <ChartCard title="By Source" data={stats.by_source} dataKey="count" labelKey="source" />
            </>
          )}
          {isLoading && [...Array(3)].map((_, i) => (
            <div key={i} className="glass-card p-6 skeleton h-64" />
          ))}
        </div>

        {/* Recent Products */}
        <div className="glass-card overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
            <h3 className="text-sm font-semibold" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', fontSize: '11px' }}>
              Recently Added
            </h3>
            <Link href="/products" className="text-xs flex items-center gap-1 transition-colors hover:text-white"
              style={{ color: '#6271f3' }}>
              View all <ArrowRight size={12} />
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>FG Code</th>
                  <th>Product Name</th>
                  <th>Category</th>
                  <th>Geo Bucket</th>
                  <th>Source</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentProducts?.results.map((p) => (
                  <tr key={p.id}>
                    <td><code className="text-xs px-2 py-0.5 rounded" style={{ background: 'rgba(98,113,243,0.1)', color: '#818cf8' }}>{p.fg_code}</code></td>
                    <td className="font-medium" style={{ color: 'var(--text-primary)', maxWidth: 200 }}>
                      <span className="truncate block">{p.product_name}</span>
                    </td>
                    <td>{p.category}</td>
                    <td>{p.geo_bucket}</td>
                    <td>
                      <span className="badge" style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-secondary)' }}>
                        {p.source}
                      </span>
                    </td>
                    <td>
                      {p.needs_evaluation ? (
                        <span className="badge" style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>Evaluate</span>
                      ) : p.is_green ? (
                        <span className="badge" style={{ background: 'rgba(16,185,129,0.15)', color: '#10b981' }}>Green</span>
                      ) : (
                        <span className="badge" style={{ background: 'rgba(98,113,243,0.15)', color: '#818cf8' }}>Active</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
