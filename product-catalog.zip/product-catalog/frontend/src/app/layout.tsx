import type { Metadata } from 'next';
import './globals.css';
import { Providers } from '@/components/layout/Providers';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'ProductCatalog — Enterprise Product Management',
  description: 'Professional product catalog management system',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body>
        <Providers>
          <div className="animated-bg" />
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background: '#1c2539',
                color: '#f1f5f9',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '10px',
                fontSize: '13px',
              },
              success: { iconTheme: { primary: '#10b981', secondary: '#1c2539' } },
              error: { iconTheme: { primary: '#ef4444', secondary: '#1c2539' } },
            }}
          />
        </Providers>
      </body>
    </html>
  );
}
