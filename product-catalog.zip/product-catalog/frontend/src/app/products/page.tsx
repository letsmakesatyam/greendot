'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { AppLayout } from '@/components/layout/AppLayout';
import { ProductTable } from '@/components/products/ProductTable';
import { ProductForm } from '@/components/products/ProductForm';
import { ProductDetail } from '@/components/products/ProductDetail';
import { Modal } from '@/components/ui/Modal';
import { productsApi, Product } from '@/lib/api';
import { Search, Plus, Filter, X, Package } from 'lucide-react';
import { useSearchParams } from 'next/navigation';

const inputStyle = {
  background: 'rgba(255,255,255,0.04)',
  border: '1px solid rgba(255,255,255,0.1)',
  color: 'var(--text-primary)',
  borderRadius: '10px',
  padding: '8px 12px',
  fontSize: '13px',
  width: '100%',
  outline: 'none',
};

export default function ProductsPage() {
  const searchParams = useSearchParams();
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState<Record<string, string>>({
    is_green: searchParams.get('is_green') || '',
    needs_evaluation: searchParams.get('needs_evaluation') || '',
    is_active: searchParams.get('is_active') || '',
    category: '',
    geo_bucket: '',
    source: '',
    product_hierarchy: '',
  });
  const [showFilters, setShowFilters] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [viewProduct, setViewProduct] = useState<Product | null>(null);

  const { data: choices } = useQuery({
    queryKey: ['choices'],
    queryFn: () => productsApi.choices().then(r => r.data),
  });

  const activeFilters = Object.entries(filters).filter(([, v]) => v).length;
  const queryFilters: Record<string, string> = {};
  if (search) queryFilters.search = search;
  Object.entries(filters).forEach(([k, v]) => { if (v) queryFilters[k] = v; });

  const selectStyle = {
    ...inputStyle,
    width: 'auto',
    minWidth: 140,
    cursor: 'pointer',
  };

  return (
    <AppLayout>
      <div className="p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Package size={14} style={{ color: '#6271f3' }} />
              <span className="text-xs font-medium" style={{ color: '#6271f3', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                Catalog
              </span>
            </div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--text-primary)' }}>
              Products
            </h1>
          </div>
          <button onClick={() => setCreateOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90"
            style={{ background: 'linear-gradient(135deg, #6271f3, #818cf8)' }}>
            <Plus size={16} /> Add Product
          </button>
        </div>

        {/* Search & Filters */}
        <div className="glass-card p-4 mb-6">
          <div className="flex gap-3 items-center">
            <div className="flex-1 relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search products, FG codes, applications..."
                style={{ ...inputStyle, paddingLeft: '36px' }}
              />
            </div>
            <button onClick={() => setShowFilters(f => !f)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all"
              style={{
                background: showFilters ? 'rgba(98,113,243,0.15)' : 'rgba(255,255,255,0.06)',
                color: showFilters ? '#818cf8' : 'var(--text-secondary)',
                border: showFilters ? '1px solid rgba(98,113,243,0.3)' : '1px solid rgba(255,255,255,0.08)',
              }}>
              <Filter size={14} />
              Filters
              {activeFilters > 0 && (
                <span className="w-4 h-4 rounded-full text-xs flex items-center justify-center text-white"
                  style={{ background: '#6271f3', fontSize: '10px' }}>{activeFilters}</span>
              )}
            </button>
            {activeFilters > 0 && (
              <button onClick={() => setFilters({ is_green: '', needs_evaluation: '', is_active: '', category: '', geo_bucket: '', source: '', product_hierarchy: '' })}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs transition-all"
                style={{ color: '#ef4444', background: 'rgba(239,68,68,0.1)' }}>
                <X size={12} /> Clear
              </button>
            )}
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 flex flex-wrap gap-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.06)' }}>
              {[
                { key: 'category', label: 'Category', options: choices?.categories ?? [] },
                { key: 'geo_bucket', label: 'Geo Bucket', options: choices?.geo_buckets ?? [] },
                { key: 'source', label: 'Source', options: choices?.sources ?? [] },
                { key: 'product_hierarchy', label: 'Hierarchy', options: choices?.product_hierarchies ?? [] },
              ].map(({ key, label, options }) => (
                <select key={key} value={filters[key]} onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))}
                  style={{ ...selectStyle, background: '#161d2e' }}>
                  <option value="">All {label}</option>
                  {options.map(o => <option key={o} value={o} style={{ background: '#161d2e' }}>{o}</option>)}
                </select>
              ))}
              {[
                { key: 'is_green', label: 'Green' },
                { key: 'needs_evaluation', label: 'Needs Eval' },
                { key: 'is_active', label: 'Active' },
              ].map(({ key, label }) => (
                <select key={key} value={filters[key]} onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))}
                  style={{ ...selectStyle, background: '#161d2e' }}>
                  <option value="">All ({label})</option>
                  <option value="true" style={{ background: '#161d2e' }}>Yes</option>
                  <option value="false" style={{ background: '#161d2e' }}>No</option>
                </select>
              ))}
            </div>
          )}
        </div>

        {/* Table */}
        <ProductTable
          filters={queryFilters}
          onEdit={setEditProduct}
          onView={setViewProduct}
          isAdmin={true}
        />
      </div>

      {/* Create Modal */}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Add New Product" size="xl">
        <ProductForm onSuccess={() => setCreateOpen(false)} onCancel={() => setCreateOpen(false)} />
      </Modal>

      {/* Edit Modal */}
      <Modal open={!!editProduct} onClose={() => setEditProduct(null)} title="Edit Product" size="xl">
        {editProduct && (
          <ProductForm product={editProduct} onSuccess={() => setEditProduct(null)} onCancel={() => setEditProduct(null)} />
        )}
      </Modal>

      {/* View Modal */}
      <Modal open={!!viewProduct} onClose={() => setViewProduct(null)} title="Product Details" size="md">
        {viewProduct && <ProductDetail product={viewProduct} />}
      </Modal>
    </AppLayout>
  );
}
