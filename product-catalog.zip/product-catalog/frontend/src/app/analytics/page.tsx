'use client';
import { useQuery } from '@tanstack/react-query';
import { AppLayout } from '@/components/layout/AppLayout';
import { productsApi } from '@/lib/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from 'recharts';
import { BarChart3 } from 'lucide-react';

const COLORS = ['#6271f3', '#818cf8', '#a78bfa', '#c4b5fd', '#7dd3fc', '#67e8f9', '#86efac'];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="px-3 py-2 rounded-lg text-xs" style={{ background: '#1c2539', border: '1px solid rgba(255,255,255,0.1)', color: '#f1f5f9' }}>
      <p style={{ color: '#94a3b8' }}>{label}</p>
      <p className="font-semibold">{payload[0].value} products</p>
    </div>
  );
};

export default function AnalyticsPage() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => productsApi.stats().then(r => r.data),
  });

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 size={14} style={{ color: '#6271f3' }} />
            <span className="text-xs font-medium" style={{ color: '#6271f3', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Analytics</span>
          </div>
          <h1 className="text-2xl font-bold gradient-text" style={{ fontFamily: 'Syne, sans-serif' }}>
            Product Analytics
          </h1>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 gap-6">{[...Array(4)].map((_, i) => <div key={i} className="glass-card p-6 skeleton h-72" />)}</div>
        ) : stats && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Category */}
            <div className="glass-card p-6">
              <h3 className="text-xs font-semibold mb-6 uppercase tracking-widest" style={{ color: 'var(--text-muted)', fontFamily: 'Syne, sans-serif' }}>
                Products by Category
              </h3>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={stats.by_category} layout="vertical" margin={{ left: 20, right: 20 }}>
                  <XAxis type="number" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="category" tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} width={120} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {stats.by_category.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Geo Bucket Pie */}
            <div className="glass-card p-6">
              <h3 className="text-xs font-semibold mb-6 uppercase tracking-widest" style={{ color: 'var(--text-muted)', fontFamily: 'Syne, sans-serif' }}>
                Distribution by Geo Bucket
              </h3>
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={stats.by_geo_bucket} dataKey="count" nameKey="geo_bucket" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                    {stats.by_geo_bucket.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Source */}
            <div className="glass-card p-6">
              <h3 className="text-xs font-semibold mb-6 uppercase tracking-widest" style={{ color: 'var(--text-muted)', fontFamily: 'Syne, sans-serif' }}>
                Products by Source
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={stats.by_source}>
                  <XAxis dataKey="source" tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {stats.by_source.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Summary Cards */}
            <div className="glass-card p-6">
              <h3 className="text-xs font-semibold mb-6 uppercase tracking-widest" style={{ color: 'var(--text-muted)', fontFamily: 'Syne, sans-serif' }}>
                Key Metrics
              </h3>
              <div className="space-y-4">
                {[
                  { label: 'Total Products', value: stats.total, color: '#6271f3' },
                  { label: 'Active Products', value: stats.active, color: '#10b981' },
                  { label: 'Green / Eco Products', value: stats.green_products, color: '#10b981' },
                  { label: 'Pending Evaluation', value: stats.needs_evaluation, color: '#f59e0b' },
                ].map(({ label, value, color }) => (
                  <div key={label}>
                    <div className="flex justify-between text-sm mb-1.5">
                      <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
                      <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>{value}</span>
                    </div>
                    <div className="h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.06)' }}>
                      <div className="h-full rounded-full transition-all" style={{ width: `${(value / stats.total) * 100}%`, background: color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
