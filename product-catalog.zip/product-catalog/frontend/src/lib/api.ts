import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: { 'Content-Type': 'application/json' },
});

export interface Product {
  id: number;
  category: string;
  application: string;
  positioning: string;
  fg_code: string;
  product_name: string;
  product_hierarchy: string;
  application_type: string;
  geo_bucket: string;
  pack_size: string;
  source: string;
  is_green: boolean;
  fc: string;
  flag_est: number;
  flag_ke: number;
  flag_extra1: number;
  flag_extra2: number;
  needs_evaluation: boolean;
  is_export: boolean;
  product_image: string | null;
  product_image_url: string | null;
  description: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductListResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: Product[];
}

export interface Stats {
  total: number;
  active: number;
  needs_evaluation: number;
  green_products: number;
  by_category: { category: string; count: number }[];
  by_geo_bucket: { geo_bucket: string; count: number }[];
  by_source: { source: string; count: number }[];
}

export interface Choices {
  categories: string[];
  geo_buckets: string[];
  product_hierarchies: string[];
  sources: string[];
}

export const productsApi = {
  list: (params?: Record<string, string | number | boolean>) =>
    api.get<ProductListResponse>('/products/', { params }),

  get: (id: number) => api.get<Product>(`/products/${id}/`),

  create: (data: FormData) =>
    api.post<Product>('/products/', data, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),

  update: (id: number, data: FormData) =>
    api.patch<Product>(`/products/${id}/`, data, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),

  delete: (id: number) => api.delete(`/products/${id}/`),

  stats: () => api.get<Stats>('/products/stats/'),

  choices: () => api.get<Choices>('/products/choices/'),

  bulkImport: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post('/products/bulk_import/', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  exportCsv: () =>
    api.get('/products/export_csv/', { responseType: 'blob' }),
};
