import django_filters
from .models import Product

class ProductFilter(django_filters.FilterSet):
    category = django_filters.CharFilter(lookup_expr='icontains')
    application = django_filters.CharFilter(lookup_expr='icontains')
    fg_code = django_filters.CharFilter(lookup_expr='icontains')
    product_name = django_filters.CharFilter(lookup_expr='icontains')
    geo_bucket = django_filters.CharFilter(lookup_expr='exact')
    source = django_filters.CharFilter(lookup_expr='exact')
    product_hierarchy = django_filters.CharFilter(lookup_expr='exact')
    is_green = django_filters.BooleanFilter()
    needs_evaluation = django_filters.BooleanFilter()
    is_active = django_filters.BooleanFilter()

    class Meta:
        model = Product
        fields = ['category', 'application', 'fg_code', 'product_name',
                  'geo_bucket', 'source', 'product_hierarchy', 'is_green',
                  'needs_evaluation', 'is_active']
