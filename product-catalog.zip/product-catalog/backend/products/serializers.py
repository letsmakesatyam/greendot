from rest_framework import serializers
from .models import Product

class ProductSerializer(serializers.ModelSerializer):
    product_image_url = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = '__all__'

    def get_product_image_url(self, obj):
        if obj.product_image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.product_image.url)
            return obj.product_image.url
        return None

class ProductListSerializer(serializers.ModelSerializer):
    product_image_url = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = [
            'id', 'category', 'application', 'positioning', 'fg_code',
            'product_name', 'product_hierarchy', 'application_type',
            'geo_bucket', 'pack_size', 'source', 'is_green', 'fc',
            'flag_est', 'flag_ke', 'needs_evaluation', 'is_export',
            'product_image_url', 'is_active', 'created_at'
        ]

    def get_product_image_url(self, obj):
        if obj.product_image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.product_image.url)
            return obj.product_image.url
        return None
