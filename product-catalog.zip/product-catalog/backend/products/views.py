from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Count, Q
from .models import Product
from .serializers import ProductSerializer, ProductListSerializer
from .filters import ProductFilter
import csv
import io
from django.http import HttpResponse

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = ProductFilter
    search_fields = ['product_name', 'fg_code', 'application', 'category', 'positioning']
    ordering_fields = ['category', 'application', 'fg_code', 'product_name', 'created_at']
    ordering = ['category', 'application']

    def get_serializer_class(self):
        if self.action == 'list':
            return ProductListSerializer
        return ProductSerializer

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    @action(detail=False, methods=['get'])
    def stats(self, request):
        total = Product.objects.count()
        active = Product.objects.filter(is_active=True).count()
        needs_eval = Product.objects.filter(needs_evaluation=True).count()
        green = Product.objects.filter(is_green=True).count()
        by_category = list(
            Product.objects.values('category').annotate(count=Count('id')).order_by('-count')
        )
        by_geo = list(
            Product.objects.values('geo_bucket').annotate(count=Count('id')).order_by('-count')
        )
        by_source = list(
            Product.objects.values('source').annotate(count=Count('id')).order_by('-count')
        )
        return Response({
            'total': total,
            'active': active,
            'needs_evaluation': needs_eval,
            'green_products': green,
            'by_category': by_category,
            'by_geo_bucket': by_geo,
            'by_source': by_source,
        })

    @action(detail=False, methods=['get'])
    def choices(self, request):
        return Response({
            'categories': [c[0] for c in Product.CATEGORY_CHOICES],
            'geo_buckets': [c[0] for c in Product.GEO_BUCKET_CHOICES],
            'product_hierarchies': [c[0] for c in Product.PRODUCT_HIERARCHY_CHOICES],
            'sources': [c[0] for c in Product.SOURCE_CHOICES],
        })

    @action(detail=False, methods=['post'])
    def bulk_import(self, request):
        csv_file = request.FILES.get('file')
        if not csv_file:
            return Response({'error': 'No file provided'}, status=400)
        decoded = csv_file.read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(decoded))
        created, updated, errors = 0, 0, []
        for i, row in enumerate(reader):
            try:
                fg_code = row.get('fg_code', '').strip()
                if not fg_code:
                    errors.append(f"Row {i+2}: Missing fg_code")
                    continue
                obj, was_created = Product.objects.update_or_create(
                    fg_code=fg_code,
                    defaults={
                        'category': row.get('category', 'Building Care').strip(),
                        'application': row.get('application', '').strip(),
                        'positioning': row.get('positioning', '').strip(),
                        'product_name': row.get('product_name', '').strip(),
                        'product_hierarchy': row.get('product_hierarchy', 'Core').strip(),
                        'application_type': row.get('application_type', '').strip(),
                        'geo_bucket': row.get('geo_bucket', 'MEA Core').strip(),
                        'pack_size': row.get('pack_size', '').strip(),
                        'source': row.get('source', 'EU').strip(),
                        'is_green': row.get('is_green', 'false').lower() == 'true',
                        'fc': row.get('fc', '').strip(),
                        'flag_est': int(row.get('flag_est', 0) or 0),
                        'flag_ke': int(row.get('flag_ke', 0) or 0),
                        'needs_evaluation': row.get('needs_evaluation', 'false').lower() == 'true',
                    }
                )
                if was_created:
                    created += 1
                else:
                    updated += 1
            except Exception as e:
                errors.append(f"Row {i+2}: {str(e)}")
        return Response({'created': created, 'updated': updated, 'errors': errors})

    @action(detail=False, methods=['get'])
    def export_csv(self, request):
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="products.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'fg_code', 'category', 'application', 'positioning', 'product_name',
            'product_hierarchy', 'application_type', 'geo_bucket', 'pack_size',
            'source', 'is_green', 'fc', 'flag_est', 'flag_ke', 'needs_evaluation',
            'is_export', 'description', 'is_active'
        ])
        for p in Product.objects.all():
            writer.writerow([
                p.fg_code, p.category, p.application, p.positioning, p.product_name,
                p.product_hierarchy, p.application_type, p.geo_bucket, p.pack_size,
                p.source, p.is_green, p.fc, p.flag_est, p.flag_ke, p.needs_evaluation,
                p.is_export, p.description, p.is_active
            ])
        return response
