from django.contrib import admin
from .models import Product

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['fg_code', 'product_name', 'category', 'application', 'geo_bucket', 'source', 'is_green', 'needs_evaluation', 'is_active']
    list_filter = ['category', 'geo_bucket', 'source', 'product_hierarchy', 'is_green', 'needs_evaluation', 'is_active']
    search_fields = ['fg_code', 'product_name', 'application', 'category']
    list_editable = ['is_active', 'needs_evaluation']
    ordering = ['category', 'application', 'product_name']
