from django.db import models

class Product(models.Model):
    CATEGORY_CHOICES = [
        ('Building Care', 'Building Care'),
        ('Food & Beverage', 'Food & Beverage'),
        ('Healthcare', 'Healthcare'),
        ('Industrial', 'Industrial'),
        ('Personal Care', 'Personal Care'),
        ('Other', 'Other'),
    ]
    GEO_BUCKET_CHOICES = [
        ('MEA Core', 'MEA Core'),
        ('MEP Only', 'MEP Only'),
        ('T&I Only', 'T&I Only'),
        ('Global', 'Global'),
    ]
    PRODUCT_HIERARCHY_CHOICES = [
        ('Core', 'Core'),
        ('Enhanced', 'Enhanced'),
        ('Specialty', 'Specialty'),
        ('Country', 'Country'),
    ]
    SOURCE_CHOICES = [
        ('EU', 'EU'),
        ('US', 'US'),
        ('TR', 'TR'),
        ('UAE', 'UAE'),
        ('IN', 'IN'),
    ]

    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES, default='Building Care')
    application = models.CharField(max_length=200)
    positioning = models.CharField(max_length=300)
    fg_code = models.CharField(max_length=50, unique=True)
    product_name = models.CharField(max_length=300)
    product_hierarchy = models.CharField(max_length=100, choices=PRODUCT_HIERARCHY_CHOICES, default='Core')
    application_type = models.CharField(max_length=100, blank=True)
    geo_bucket = models.CharField(max_length=100, choices=GEO_BUCKET_CHOICES, default='MEA Core')
    pack_size = models.CharField(max_length=50, blank=True)
    source = models.CharField(max_length=50, choices=SOURCE_CHOICES, default='EU')
    is_green = models.BooleanField(default=False)
    fc = models.CharField(max_length=50, blank=True)
    flag_est = models.IntegerField(default=0)
    flag_ke = models.IntegerField(default=0)
    flag_extra1 = models.IntegerField(default=0)
    flag_extra2 = models.IntegerField(default=0)
    needs_evaluation = models.BooleanField(default=False)
    is_export = models.BooleanField(default=False)
    product_image = models.ImageField(upload_to='product_images/', blank=True, null=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['category', 'application', 'product_name']

    def __str__(self):
        return f"{self.fg_code} - {self.product_name}"
